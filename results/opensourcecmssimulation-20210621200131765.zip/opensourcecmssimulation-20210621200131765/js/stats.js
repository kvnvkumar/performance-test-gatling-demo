var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "117",
        "ok": "117",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "199",
        "ok": "199",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1986",
        "ok": "1986",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "629",
        "ok": "629",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "488",
        "ok": "488",
        "ko": "-"
    },
    "percentiles1": {
        "total": "376",
        "ok": "376",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1043",
        "ok": "1043",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1568",
        "ok": "1568",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1740",
        "ok": "1740",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 79,
    "percentage": 68
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 20,
    "percentage": 17
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 18,
    "percentage": 15
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.6",
        "ok": "2.6",
        "ko": "-"
    }
},
contents: {
"req_a01-homepage-14fe3": {
        type: "REQUEST",
        name: "A01_HomePage",
path: "A01_HomePage",
pathFormatted: "req_a01-homepage-14fe3",
stats: {
    "name": "A01_HomePage",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1421",
        "ok": "1421",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1421",
        "ok": "1421",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1421",
        "ok": "1421",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1421",
        "ok": "1421",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1421",
        "ok": "1421",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1421",
        "ok": "1421",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1421",
        "ok": "1421",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_favicon-ico-8af3a": {
        type: "REQUEST",
        name: "favicon.ico",
path: "favicon.ico",
pathFormatted: "req_favicon-ico-8af3a",
stats: {
    "name": "favicon.ico",
    "numberOfRequests": {
        "total": "5",
        "ok": "5",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "199",
        "ok": "199",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "398",
        "ok": "398",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "266",
        "ok": "266",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "70",
        "ok": "70",
        "ko": "-"
    },
    "percentiles1": {
        "total": "238",
        "ok": "238",
        "ko": "-"
    },
    "percentiles2": {
        "total": "272",
        "ok": "272",
        "ko": "-"
    },
    "percentiles3": {
        "total": "373",
        "ok": "373",
        "ko": "-"
    },
    "percentiles4": {
        "total": "393",
        "ok": "393",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 5,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.111",
        "ok": "0.111",
        "ko": "-"
    }
}
    },"req_reset-css-d4042": {
        type: "REQUEST",
        name: "reset.css",
path: "reset.css",
pathFormatted: "req_reset-css-d4042",
stats: {
    "name": "reset.css",
    "numberOfRequests": {
        "total": "5",
        "ok": "5",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "899",
        "ok": "899",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1986",
        "ok": "1986",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1239",
        "ok": "1239",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "385",
        "ok": "385",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1137",
        "ok": "1137",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1152",
        "ok": "1152",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1819",
        "ok": "1819",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1953",
        "ok": "1953",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 80
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 20
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.111",
        "ok": "0.111",
        "ko": "-"
    }
}
    },"req_tiptip-css-6fe70": {
        type: "REQUEST",
        name: "tipTip.css",
path: "tipTip.css",
pathFormatted: "req_tiptip-css-6fe70",
stats: {
    "name": "tipTip.css",
    "numberOfRequests": {
        "total": "5",
        "ok": "5",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1015",
        "ok": "1015",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1565",
        "ok": "1565",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1182",
        "ok": "1182",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "196",
        "ok": "196",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1111",
        "ok": "1111",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1142",
        "ok": "1142",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1480",
        "ok": "1480",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1548",
        "ok": "1548",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 80
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 20
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.111",
        "ok": "0.111",
        "ko": "-"
    }
}
    },"req_jquery-ui-1-8-2-caac3": {
        type: "REQUEST",
        name: "jquery-ui-1.8.21.custom.css",
path: "jquery-ui-1.8.21.custom.css",
pathFormatted: "req_jquery-ui-1-8-2-caac3",
stats: {
    "name": "jquery-ui-1.8.21.custom.css",
    "numberOfRequests": {
        "total": "5",
        "ok": "5",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "931",
        "ok": "931",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1581",
        "ok": "1581",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1329",
        "ok": "1329",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "247",
        "ok": "247",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1475",
        "ok": "1475",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1505",
        "ok": "1505",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1566",
        "ok": "1566",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1578",
        "ok": "1578",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 40
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3,
    "percentage": 60
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.111",
        "ok": "0.111",
        "ko": "-"
    }
}
    },"req_jquery-autocomp-ee752": {
        type: "REQUEST",
        name: "jquery.autocomplete.css",
path: "jquery.autocomplete.css",
pathFormatted: "req_jquery-autocomp-ee752",
stats: {
    "name": "jquery.autocomplete.css",
    "numberOfRequests": {
        "total": "5",
        "ok": "5",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "945",
        "ok": "945",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1586",
        "ok": "1586",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1197",
        "ok": "1197",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "211",
        "ok": "211",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1163",
        "ok": "1163",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1173",
        "ok": "1173",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1503",
        "ok": "1503",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1569",
        "ok": "1569",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 80
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 20
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.111",
        "ok": "0.111",
        "ko": "-"
    }
}
    },"req_main-css-4abed": {
        type: "REQUEST",
        name: "main.css",
path: "main.css",
pathFormatted: "req_main-css-4abed",
stats: {
    "name": "main.css",
    "numberOfRequests": {
        "total": "5",
        "ok": "5",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1028",
        "ok": "1028",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1596",
        "ok": "1596",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1375",
        "ok": "1375",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "226",
        "ok": "226",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1531",
        "ok": "1531",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1536",
        "ok": "1536",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1584",
        "ok": "1584",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1594",
        "ok": "1594",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 40
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3,
    "percentage": 60
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.111",
        "ok": "0.111",
        "ko": "-"
    }
}
    },"req_jquery-1-7-2-mi-838cf": {
        type: "REQUEST",
        name: "jquery-1.7.2.min.js",
path: "jquery-1.7.2.min.js",
pathFormatted: "req_jquery-1-7-2-mi-838cf",
stats: {
    "name": "jquery-1.7.2.min.js",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1328",
        "ok": "1328",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1591",
        "ok": "1591",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1460",
        "ok": "1460",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "132",
        "ok": "132",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1460",
        "ok": "1460",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1525",
        "ok": "1525",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1578",
        "ok": "1578",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1588",
        "ok": "1588",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.044",
        "ok": "0.044",
        "ko": "-"
    }
}
    },"req_jquery-validate-a6920": {
        type: "REQUEST",
        name: "jquery.validate.js",
path: "jquery.validate.js",
pathFormatted: "req_jquery-validate-a6920",
stats: {
    "name": "jquery.validate.js",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "594",
        "ok": "594",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "602",
        "ok": "602",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "598",
        "ok": "598",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "percentiles1": {
        "total": "598",
        "ok": "598",
        "ko": "-"
    },
    "percentiles2": {
        "total": "600",
        "ok": "600",
        "ko": "-"
    },
    "percentiles3": {
        "total": "602",
        "ok": "602",
        "ko": "-"
    },
    "percentiles4": {
        "total": "602",
        "ok": "602",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.044",
        "ok": "0.044",
        "ko": "-"
    }
}
    },"req_jquery-ui-core--0127c": {
        type: "REQUEST",
        name: "jquery.ui.core.js",
path: "jquery.ui.core.js",
pathFormatted: "req_jquery-ui-core--0127c",
stats: {
    "name": "jquery.ui.core.js",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "227",
        "ok": "227",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "243",
        "ok": "243",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "235",
        "ok": "235",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "percentiles1": {
        "total": "235",
        "ok": "235",
        "ko": "-"
    },
    "percentiles2": {
        "total": "239",
        "ok": "239",
        "ko": "-"
    },
    "percentiles3": {
        "total": "242",
        "ok": "242",
        "ko": "-"
    },
    "percentiles4": {
        "total": "243",
        "ok": "243",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.044",
        "ok": "0.044",
        "ko": "-"
    }
}
    },"req_jquery-autocomp-738ff": {
        type: "REQUEST",
        name: "jquery.autocomplete.js",
path: "jquery.autocomplete.js",
pathFormatted: "req_jquery-autocomp-738ff",
stats: {
    "name": "jquery.autocomplete.js",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "404",
        "ok": "404",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "467",
        "ok": "467",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "436",
        "ok": "436",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "32",
        "ok": "32",
        "ko": "-"
    },
    "percentiles1": {
        "total": "436",
        "ok": "436",
        "ko": "-"
    },
    "percentiles2": {
        "total": "451",
        "ok": "451",
        "ko": "-"
    },
    "percentiles3": {
        "total": "464",
        "ok": "464",
        "ko": "-"
    },
    "percentiles4": {
        "total": "466",
        "ok": "466",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.044",
        "ok": "0.044",
        "ko": "-"
    }
}
    },"req_orangehrm-autoc-ddbf2": {
        type: "REQUEST",
        name: "orangehrm.autocomplete.js",
path: "orangehrm.autocomplete.js",
pathFormatted: "req_orangehrm-autoc-ddbf2",
stats: {
    "name": "orangehrm.autocomplete.js",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "259",
        "ok": "259",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "245",
        "ok": "245",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "percentiles1": {
        "total": "245",
        "ok": "245",
        "ko": "-"
    },
    "percentiles2": {
        "total": "252",
        "ok": "252",
        "ko": "-"
    },
    "percentiles3": {
        "total": "258",
        "ok": "258",
        "ko": "-"
    },
    "percentiles4": {
        "total": "259",
        "ok": "259",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.044",
        "ok": "0.044",
        "ko": "-"
    }
}
    },"req_jquery-ui-datep-2e35e": {
        type: "REQUEST",
        name: "jquery.ui.datepicker.js",
path: "jquery.ui.datepicker.js",
pathFormatted: "req_jquery-ui-datep-2e35e",
stats: {
    "name": "jquery.ui.datepicker.js",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1005",
        "ok": "1005",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1030",
        "ok": "1030",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1018",
        "ok": "1018",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1018",
        "ok": "1018",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1024",
        "ok": "1024",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1029",
        "ok": "1029",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1030",
        "ok": "1030",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 100
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.044",
        "ok": "0.044",
        "ko": "-"
    }
}
    },"req_jquery-form-js-d4883": {
        type: "REQUEST",
        name: "jquery.form.js",
path: "jquery.form.js",
pathFormatted: "req_jquery-form-js-d4883",
stats: {
    "name": "jquery.form.js",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "429",
        "ok": "429",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "434",
        "ok": "434",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "432",
        "ok": "432",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "percentiles1": {
        "total": "432",
        "ok": "432",
        "ko": "-"
    },
    "percentiles2": {
        "total": "433",
        "ok": "433",
        "ko": "-"
    },
    "percentiles3": {
        "total": "434",
        "ok": "434",
        "ko": "-"
    },
    "percentiles4": {
        "total": "434",
        "ok": "434",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.044",
        "ok": "0.044",
        "ko": "-"
    }
}
    },"req_jquery-tiptip-m-76521": {
        type: "REQUEST",
        name: "jquery.tipTip.minified.js",
path: "jquery.tipTip.minified.js",
pathFormatted: "req_jquery-tiptip-m-76521",
stats: {
    "name": "jquery.tipTip.minified.js",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "219",
        "ok": "219",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "242",
        "ok": "242",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "231",
        "ok": "231",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles1": {
        "total": "231",
        "ok": "231",
        "ko": "-"
    },
    "percentiles2": {
        "total": "236",
        "ok": "236",
        "ko": "-"
    },
    "percentiles3": {
        "total": "241",
        "ok": "241",
        "ko": "-"
    },
    "percentiles4": {
        "total": "242",
        "ok": "242",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.044",
        "ok": "0.044",
        "ko": "-"
    }
}
    },"req_bootstrap-modal-8c227": {
        type: "REQUEST",
        name: "bootstrap-modal.js",
path: "bootstrap-modal.js",
pathFormatted: "req_bootstrap-modal-8c227",
stats: {
    "name": "bootstrap-modal.js",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "233",
        "ok": "233",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "232",
        "ok": "232",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles1": {
        "total": "232",
        "ok": "232",
        "ko": "-"
    },
    "percentiles2": {
        "total": "232",
        "ok": "232",
        "ko": "-"
    },
    "percentiles3": {
        "total": "233",
        "ok": "233",
        "ko": "-"
    },
    "percentiles4": {
        "total": "233",
        "ok": "233",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.044",
        "ok": "0.044",
        "ko": "-"
    }
}
    },"req_jquery-clickout-7ee70": {
        type: "REQUEST",
        name: "jquery.clickoutside.js",
path: "jquery.clickoutside.js",
pathFormatted: "req_jquery-clickout-7ee70",
stats: {
    "name": "jquery.clickoutside.js",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "208",
        "ok": "208",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "232",
        "ok": "232",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "220",
        "ok": "220",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles1": {
        "total": "220",
        "ok": "220",
        "ko": "-"
    },
    "percentiles2": {
        "total": "226",
        "ok": "226",
        "ko": "-"
    },
    "percentiles3": {
        "total": "231",
        "ok": "231",
        "ko": "-"
    },
    "percentiles4": {
        "total": "232",
        "ok": "232",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.044",
        "ok": "0.044",
        "ko": "-"
    }
}
    },"req_orangehrm-valid-859d5": {
        type: "REQUEST",
        name: "orangehrm.validate.js",
path: "orangehrm.validate.js",
pathFormatted: "req_orangehrm-valid-859d5",
stats: {
    "name": "orangehrm.validate.js",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "208",
        "ok": "208",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "220",
        "ok": "220",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "214",
        "ok": "214",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "percentiles1": {
        "total": "214",
        "ok": "214",
        "ko": "-"
    },
    "percentiles2": {
        "total": "217",
        "ok": "217",
        "ko": "-"
    },
    "percentiles3": {
        "total": "219",
        "ok": "219",
        "ko": "-"
    },
    "percentiles4": {
        "total": "220",
        "ok": "220",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.044",
        "ok": "0.044",
        "ko": "-"
    }
}
    },"req_archive-js-66cb0": {
        type: "REQUEST",
        name: "archive.js",
path: "archive.js",
pathFormatted: "req_archive-js-66cb0",
stats: {
    "name": "archive.js",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "217",
        "ok": "217",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "228",
        "ok": "228",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "223",
        "ok": "223",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "percentiles1": {
        "total": "223",
        "ok": "223",
        "ko": "-"
    },
    "percentiles2": {
        "total": "225",
        "ok": "225",
        "ko": "-"
    },
    "percentiles3": {
        "total": "227",
        "ok": "227",
        "ko": "-"
    },
    "percentiles4": {
        "total": "228",
        "ok": "228",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.044",
        "ok": "0.044",
        "ko": "-"
    }
}
    },"req_logo-png-1bb87": {
        type: "REQUEST",
        name: "logo.png",
path: "logo.png",
pathFormatted: "req_logo-png-1bb87",
stats: {
    "name": "logo.png",
    "numberOfRequests": {
        "total": "3",
        "ok": "3",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "226",
        "ok": "226",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "612",
        "ok": "612",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "475",
        "ok": "475",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "177",
        "ok": "177",
        "ko": "-"
    },
    "percentiles1": {
        "total": "588",
        "ok": "588",
        "ko": "-"
    },
    "percentiles2": {
        "total": "600",
        "ok": "600",
        "ko": "-"
    },
    "percentiles3": {
        "total": "610",
        "ok": "610",
        "ko": "-"
    },
    "percentiles4": {
        "total": "612",
        "ok": "612",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 3,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_linkedin-png-fdff0": {
        type: "REQUEST",
        name: "linkedin.png",
path: "linkedin.png",
pathFormatted: "req_linkedin-png-fdff0",
stats: {
    "name": "linkedin.png",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "215",
        "ok": "215",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "217",
        "ok": "217",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "216",
        "ok": "216",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "percentiles1": {
        "total": "216",
        "ok": "216",
        "ko": "-"
    },
    "percentiles2": {
        "total": "217",
        "ok": "217",
        "ko": "-"
    },
    "percentiles3": {
        "total": "217",
        "ok": "217",
        "ko": "-"
    },
    "percentiles4": {
        "total": "217",
        "ok": "217",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.044",
        "ok": "0.044",
        "ko": "-"
    }
}
    },"req_facebook-png-3d31e": {
        type: "REQUEST",
        name: "facebook.png",
path: "facebook.png",
pathFormatted: "req_facebook-png-3d31e",
stats: {
    "name": "facebook.png",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "213",
        "ok": "213",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "228",
        "ok": "228",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "221",
        "ok": "221",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "percentiles1": {
        "total": "221",
        "ok": "221",
        "ko": "-"
    },
    "percentiles2": {
        "total": "224",
        "ok": "224",
        "ko": "-"
    },
    "percentiles3": {
        "total": "227",
        "ok": "227",
        "ko": "-"
    },
    "percentiles4": {
        "total": "228",
        "ok": "228",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.044",
        "ok": "0.044",
        "ko": "-"
    }
}
    },"req_twiter-png-b2845": {
        type: "REQUEST",
        name: "twiter.png",
path: "twiter.png",
pathFormatted: "req_twiter-png-b2845",
stats: {
    "name": "twiter.png",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "232",
        "ok": "232",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "246",
        "ok": "246",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "239",
        "ok": "239",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "percentiles1": {
        "total": "239",
        "ok": "239",
        "ko": "-"
    },
    "percentiles2": {
        "total": "243",
        "ok": "243",
        "ko": "-"
    },
    "percentiles3": {
        "total": "245",
        "ok": "245",
        "ko": "-"
    },
    "percentiles4": {
        "total": "246",
        "ok": "246",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.044",
        "ok": "0.044",
        "ko": "-"
    }
}
    },"req_youtube-png-479b2": {
        type: "REQUEST",
        name: "youtube.png",
path: "youtube.png",
pathFormatted: "req_youtube-png-479b2",
stats: {
    "name": "youtube.png",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "236",
        "ok": "236",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "247",
        "ok": "247",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "242",
        "ok": "242",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "percentiles1": {
        "total": "242",
        "ok": "242",
        "ko": "-"
    },
    "percentiles2": {
        "total": "244",
        "ok": "244",
        "ko": "-"
    },
    "percentiles3": {
        "total": "246",
        "ok": "246",
        "ko": "-"
    },
    "percentiles4": {
        "total": "247",
        "ok": "247",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.044",
        "ok": "0.044",
        "ko": "-"
    }
}
    },"req_request-11-f11e8": {
        type: "REQUEST",
        name: "request_11",
path: "request_11",
pathFormatted: "req_request-11-f11e8",
stats: {
    "name": "request_11",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1063",
        "ok": "1063",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1063",
        "ok": "1063",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1063",
        "ok": "1063",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1063",
        "ok": "1063",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1063",
        "ok": "1063",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1063",
        "ok": "1063",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1063",
        "ok": "1063",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 100
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-18-f5b64": {
        type: "REQUEST",
        name: "request_18",
path: "request_18",
pathFormatted: "req_request-18-f5b64",
stats: {
    "name": "request_18",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "439",
        "ok": "439",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "439",
        "ok": "439",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "439",
        "ok": "439",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "439",
        "ok": "439",
        "ko": "-"
    },
    "percentiles2": {
        "total": "439",
        "ok": "439",
        "ko": "-"
    },
    "percentiles3": {
        "total": "439",
        "ok": "439",
        "ko": "-"
    },
    "percentiles4": {
        "total": "439",
        "ok": "439",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-22-8ecb1": {
        type: "REQUEST",
        name: "request_22",
path: "request_22",
pathFormatted: "req_request-22-8ecb1",
stats: {
    "name": "request_22",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "271",
        "ok": "271",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "271",
        "ok": "271",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "271",
        "ok": "271",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "271",
        "ok": "271",
        "ko": "-"
    },
    "percentiles2": {
        "total": "271",
        "ok": "271",
        "ko": "-"
    },
    "percentiles3": {
        "total": "271",
        "ok": "271",
        "ko": "-"
    },
    "percentiles4": {
        "total": "271",
        "ok": "271",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-23-98f5d": {
        type: "REQUEST",
        name: "request_23",
path: "request_23",
pathFormatted: "req_request-23-98f5d",
stats: {
    "name": "request_23",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1043",
        "ok": "1043",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1043",
        "ok": "1043",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1043",
        "ok": "1043",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1043",
        "ok": "1043",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1043",
        "ok": "1043",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1043",
        "ok": "1043",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1043",
        "ok": "1043",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 100
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-24-dd0c9": {
        type: "REQUEST",
        name: "request_24",
path: "request_24",
pathFormatted: "req_request-24-dd0c9",
stats: {
    "name": "request_24",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "220",
        "ok": "220",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "220",
        "ok": "220",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "220",
        "ok": "220",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "220",
        "ok": "220",
        "ko": "-"
    },
    "percentiles2": {
        "total": "220",
        "ok": "220",
        "ko": "-"
    },
    "percentiles3": {
        "total": "220",
        "ok": "220",
        "ko": "-"
    },
    "percentiles4": {
        "total": "220",
        "ok": "220",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_a02-login-04025": {
        type: "REQUEST",
        name: "A02_Login",
path: "A02_Login",
pathFormatted: "req_a02-login-04025",
stats: {
    "name": "A02_Login",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1547",
        "ok": "1547",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1547",
        "ok": "1547",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1547",
        "ok": "1547",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1547",
        "ok": "1547",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1547",
        "ok": "1547",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1547",
        "ok": "1547",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1547",
        "ok": "1547",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_a02-login-redir-c1785": {
        type: "REQUEST",
        name: "A02_Login Redirect 1",
path: "A02_Login Redirect 1",
pathFormatted: "req_a02-login-redir-c1785",
stats: {
    "name": "A02_Login Redirect 1",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "461",
        "ok": "461",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "461",
        "ok": "461",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "461",
        "ok": "461",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "461",
        "ok": "461",
        "ko": "-"
    },
    "percentiles2": {
        "total": "461",
        "ok": "461",
        "ko": "-"
    },
    "percentiles3": {
        "total": "461",
        "ok": "461",
        "ko": "-"
    },
    "percentiles4": {
        "total": "461",
        "ok": "461",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_-beaconabout-cs-31765": {
        type: "REQUEST",
        name: "_beaconAbout.css",
path: "_beaconAbout.css",
pathFormatted: "req_-beaconabout-cs-31765",
stats: {
    "name": "_beaconAbout.css",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "237",
        "ok": "237",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "237",
        "ok": "237",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "237",
        "ok": "237",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "237",
        "ok": "237",
        "ko": "-"
    },
    "percentiles2": {
        "total": "237",
        "ok": "237",
        "ko": "-"
    },
    "percentiles3": {
        "total": "237",
        "ok": "237",
        "ko": "-"
    },
    "percentiles4": {
        "total": "237",
        "ok": "237",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_orangehrmdashbo-0738c": {
        type: "REQUEST",
        name: "orangehrmDashboardPlugin.css",
path: "orangehrmDashboardPlugin.css",
pathFormatted: "req_orangehrmdashbo-0738c",
stats: {
    "name": "orangehrmDashboardPlugin.css",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "252",
        "ok": "252",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "252",
        "ok": "252",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "252",
        "ok": "252",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "252",
        "ok": "252",
        "ko": "-"
    },
    "percentiles2": {
        "total": "252",
        "ok": "252",
        "ko": "-"
    },
    "percentiles3": {
        "total": "252",
        "ok": "252",
        "ko": "-"
    },
    "percentiles4": {
        "total": "252",
        "ok": "252",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_applyleave-png-4922e": {
        type: "REQUEST",
        name: "ApplyLeave.png",
path: "ApplyLeave.png",
pathFormatted: "req_applyleave-png-4922e",
stats: {
    "name": "ApplyLeave.png",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "285",
        "ok": "285",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "285",
        "ok": "285",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "285",
        "ok": "285",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "285",
        "ok": "285",
        "ko": "-"
    },
    "percentiles2": {
        "total": "285",
        "ok": "285",
        "ko": "-"
    },
    "percentiles3": {
        "total": "285",
        "ok": "285",
        "ko": "-"
    },
    "percentiles4": {
        "total": "285",
        "ok": "285",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_myleave-png-7c23d": {
        type: "REQUEST",
        name: "MyLeave.png",
path: "MyLeave.png",
pathFormatted: "req_myleave-png-7c23d",
stats: {
    "name": "MyLeave.png",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "297",
        "ok": "297",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "297",
        "ok": "297",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "297",
        "ok": "297",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "297",
        "ok": "297",
        "ko": "-"
    },
    "percentiles2": {
        "total": "297",
        "ok": "297",
        "ko": "-"
    },
    "percentiles3": {
        "total": "297",
        "ok": "297",
        "ko": "-"
    },
    "percentiles4": {
        "total": "297",
        "ok": "297",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_mytimesheet-png-dffb3": {
        type: "REQUEST",
        name: "MyTimesheet.png",
path: "MyTimesheet.png",
pathFormatted: "req_mytimesheet-png-dffb3",
stats: {
    "name": "MyTimesheet.png",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "226",
        "ok": "226",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "226",
        "ok": "226",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "226",
        "ok": "226",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "226",
        "ok": "226",
        "ko": "-"
    },
    "percentiles2": {
        "total": "226",
        "ok": "226",
        "ko": "-"
    },
    "percentiles3": {
        "total": "226",
        "ok": "226",
        "ko": "-"
    },
    "percentiles4": {
        "total": "226",
        "ok": "226",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-31-261d3": {
        type: "REQUEST",
        name: "request_31",
path: "request_31",
pathFormatted: "req_request-31-261d3",
stats: {
    "name": "request_31",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1201",
        "ok": "1201",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1201",
        "ok": "1201",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1201",
        "ok": "1201",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1201",
        "ok": "1201",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1201",
        "ok": "1201",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1201",
        "ok": "1201",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1201",
        "ok": "1201",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-46-809be": {
        type: "REQUEST",
        name: "request_46",
path: "request_46",
pathFormatted: "req_request-46-809be",
stats: {
    "name": "request_46",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "percentiles2": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "percentiles3": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "percentiles4": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-47-f8703": {
        type: "REQUEST",
        name: "request_47",
path: "request_47",
pathFormatted: "req_request-47-f8703",
stats: {
    "name": "request_47",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "231",
        "ok": "231",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "231",
        "ok": "231",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "231",
        "ok": "231",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "231",
        "ok": "231",
        "ko": "-"
    },
    "percentiles2": {
        "total": "231",
        "ok": "231",
        "ko": "-"
    },
    "percentiles3": {
        "total": "231",
        "ok": "231",
        "ko": "-"
    },
    "percentiles4": {
        "total": "231",
        "ok": "231",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-49-5406f": {
        type: "REQUEST",
        name: "request_49",
path: "request_49",
pathFormatted: "req_request-49-5406f",
stats: {
    "name": "request_49",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "percentiles2": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "percentiles3": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "percentiles4": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-50-b37d9": {
        type: "REQUEST",
        name: "request_50",
path: "request_50",
pathFormatted: "req_request-50-b37d9",
stats: {
    "name": "request_50",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "250",
        "ok": "250",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "250",
        "ok": "250",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "250",
        "ok": "250",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "250",
        "ok": "250",
        "ko": "-"
    },
    "percentiles2": {
        "total": "250",
        "ok": "250",
        "ko": "-"
    },
    "percentiles3": {
        "total": "250",
        "ok": "250",
        "ko": "-"
    },
    "percentiles4": {
        "total": "250",
        "ok": "250",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-51-1f144": {
        type: "REQUEST",
        name: "request_51",
path: "request_51",
pathFormatted: "req_request-51-1f144",
stats: {
    "name": "request_51",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "410",
        "ok": "410",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "410",
        "ok": "410",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "410",
        "ok": "410",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "410",
        "ok": "410",
        "ko": "-"
    },
    "percentiles2": {
        "total": "410",
        "ok": "410",
        "ko": "-"
    },
    "percentiles3": {
        "total": "410",
        "ok": "410",
        "ko": "-"
    },
    "percentiles4": {
        "total": "410",
        "ok": "410",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-52-eab3a": {
        type: "REQUEST",
        name: "request_52",
path: "request_52",
pathFormatted: "req_request-52-eab3a",
stats: {
    "name": "request_52",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "330",
        "ok": "330",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "330",
        "ok": "330",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "330",
        "ok": "330",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "330",
        "ok": "330",
        "ko": "-"
    },
    "percentiles2": {
        "total": "330",
        "ok": "330",
        "ko": "-"
    },
    "percentiles3": {
        "total": "330",
        "ok": "330",
        "ko": "-"
    },
    "percentiles4": {
        "total": "330",
        "ok": "330",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-53-369eb": {
        type: "REQUEST",
        name: "request_53",
path: "request_53",
pathFormatted: "req_request-53-369eb",
stats: {
    "name": "request_53",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "331",
        "ok": "331",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "331",
        "ok": "331",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "331",
        "ok": "331",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "331",
        "ok": "331",
        "ko": "-"
    },
    "percentiles2": {
        "total": "331",
        "ok": "331",
        "ko": "-"
    },
    "percentiles3": {
        "total": "331",
        "ok": "331",
        "ko": "-"
    },
    "percentiles4": {
        "total": "331",
        "ok": "331",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-54-22e8b": {
        type: "REQUEST",
        name: "request_54",
path: "request_54",
pathFormatted: "req_request-54-22e8b",
stats: {
    "name": "request_54",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "315",
        "ok": "315",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "315",
        "ok": "315",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "315",
        "ok": "315",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "315",
        "ok": "315",
        "ko": "-"
    },
    "percentiles2": {
        "total": "315",
        "ok": "315",
        "ko": "-"
    },
    "percentiles3": {
        "total": "315",
        "ok": "315",
        "ko": "-"
    },
    "percentiles4": {
        "total": "315",
        "ok": "315",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-55-784ce": {
        type: "REQUEST",
        name: "request_55",
path: "request_55",
pathFormatted: "req_request-55-784ce",
stats: {
    "name": "request_55",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "334",
        "ok": "334",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "334",
        "ok": "334",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "334",
        "ok": "334",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "334",
        "ok": "334",
        "ko": "-"
    },
    "percentiles2": {
        "total": "334",
        "ok": "334",
        "ko": "-"
    },
    "percentiles3": {
        "total": "334",
        "ok": "334",
        "ko": "-"
    },
    "percentiles4": {
        "total": "334",
        "ok": "334",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-56-ffd25": {
        type: "REQUEST",
        name: "request_56",
path: "request_56",
pathFormatted: "req_request-56-ffd25",
stats: {
    "name": "request_56",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "405",
        "ok": "405",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "405",
        "ok": "405",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "405",
        "ok": "405",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "405",
        "ok": "405",
        "ko": "-"
    },
    "percentiles2": {
        "total": "405",
        "ok": "405",
        "ko": "-"
    },
    "percentiles3": {
        "total": "405",
        "ok": "405",
        "ko": "-"
    },
    "percentiles4": {
        "total": "405",
        "ok": "405",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-57-c84ef": {
        type: "REQUEST",
        name: "request_57",
path: "request_57",
pathFormatted: "req_request-57-c84ef",
stats: {
    "name": "request_57",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "318",
        "ok": "318",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "318",
        "ok": "318",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "318",
        "ok": "318",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "318",
        "ok": "318",
        "ko": "-"
    },
    "percentiles2": {
        "total": "318",
        "ok": "318",
        "ko": "-"
    },
    "percentiles3": {
        "total": "318",
        "ok": "318",
        "ko": "-"
    },
    "percentiles4": {
        "total": "318",
        "ok": "318",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-58-a56e4": {
        type: "REQUEST",
        name: "request_58",
path: "request_58",
pathFormatted: "req_request-58-a56e4",
stats: {
    "name": "request_58",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "percentiles2": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "percentiles3": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "percentiles4": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-59-9384e": {
        type: "REQUEST",
        name: "request_59",
path: "request_59",
pathFormatted: "req_request-59-9384e",
stats: {
    "name": "request_59",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "325",
        "ok": "325",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "325",
        "ok": "325",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "325",
        "ok": "325",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "325",
        "ok": "325",
        "ko": "-"
    },
    "percentiles2": {
        "total": "325",
        "ok": "325",
        "ko": "-"
    },
    "percentiles3": {
        "total": "325",
        "ok": "325",
        "ko": "-"
    },
    "percentiles4": {
        "total": "325",
        "ok": "325",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-60-458f3": {
        type: "REQUEST",
        name: "request_60",
path: "request_60",
pathFormatted: "req_request-60-458f3",
stats: {
    "name": "request_60",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "325",
        "ok": "325",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "325",
        "ok": "325",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "325",
        "ok": "325",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "325",
        "ok": "325",
        "ko": "-"
    },
    "percentiles2": {
        "total": "325",
        "ok": "325",
        "ko": "-"
    },
    "percentiles3": {
        "total": "325",
        "ok": "325",
        "ko": "-"
    },
    "percentiles4": {
        "total": "325",
        "ok": "325",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-61-92673": {
        type: "REQUEST",
        name: "request_61",
path: "request_61",
pathFormatted: "req_request-61-92673",
stats: {
    "name": "request_61",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "489",
        "ok": "489",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "489",
        "ok": "489",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "489",
        "ok": "489",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "489",
        "ok": "489",
        "ko": "-"
    },
    "percentiles2": {
        "total": "489",
        "ok": "489",
        "ko": "-"
    },
    "percentiles3": {
        "total": "489",
        "ok": "489",
        "ko": "-"
    },
    "percentiles4": {
        "total": "489",
        "ok": "489",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-62-c1e7c": {
        type: "REQUEST",
        name: "request_62",
path: "request_62",
pathFormatted: "req_request-62-c1e7c",
stats: {
    "name": "request_62",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "percentiles2": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "percentiles3": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "percentiles4": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_a03-clickingona-7f02b": {
        type: "REQUEST",
        name: "A03_ClickingOnAdminModule",
path: "A03_ClickingOnAdminModule",
pathFormatted: "req_a03-clickingona-7f02b",
stats: {
    "name": "A03_ClickingOnAdminModule",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1423",
        "ok": "1423",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1423",
        "ok": "1423",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1423",
        "ok": "1423",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1423",
        "ok": "1423",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1423",
        "ok": "1423",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1423",
        "ok": "1423",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1423",
        "ok": "1423",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_a03-clickingona-bdd11": {
        type: "REQUEST",
        name: "A03_ClickingOnAdminModule Redirect 1",
path: "A03_ClickingOnAdminModule Redirect 1",
pathFormatted: "req_a03-clickingona-bdd11",
stats: {
    "name": "A03_ClickingOnAdminModule Redirect 1",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "520",
        "ok": "520",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "520",
        "ok": "520",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "520",
        "ok": "520",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "520",
        "ok": "520",
        "ko": "-"
    },
    "percentiles2": {
        "total": "520",
        "ok": "520",
        "ko": "-"
    },
    "percentiles3": {
        "total": "520",
        "ok": "520",
        "ko": "-"
    },
    "percentiles4": {
        "total": "520",
        "ok": "520",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_viewsystemusers-5501a": {
        type: "REQUEST",
        name: "viewSystemUserSuccess.js",
path: "viewSystemUserSuccess.js",
pathFormatted: "req_viewsystemusers-5501a",
stats: {
    "name": "viewSystemUserSuccess.js",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "412",
        "ok": "412",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "412",
        "ok": "412",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "412",
        "ok": "412",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "412",
        "ok": "412",
        "ko": "-"
    },
    "percentiles2": {
        "total": "412",
        "ok": "412",
        "ko": "-"
    },
    "percentiles3": {
        "total": "412",
        "ok": "412",
        "ko": "-"
    },
    "percentiles4": {
        "total": "412",
        "ok": "412",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_-ohrmlist-css-12394": {
        type: "REQUEST",
        name: "_ohrmList.css",
path: "_ohrmList.css",
pathFormatted: "req_-ohrmlist-css-12394",
stats: {
    "name": "_ohrmList.css",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "306",
        "ok": "306",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "306",
        "ok": "306",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "306",
        "ok": "306",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "306",
        "ok": "306",
        "ko": "-"
    },
    "percentiles2": {
        "total": "306",
        "ok": "306",
        "ko": "-"
    },
    "percentiles3": {
        "total": "306",
        "ok": "306",
        "ko": "-"
    },
    "percentiles4": {
        "total": "306",
        "ok": "306",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_-ohrmlist-js-7d456": {
        type: "REQUEST",
        name: "_ohrmList.js",
path: "_ohrmList.js",
pathFormatted: "req_-ohrmlist-js-7d456",
stats: {
    "name": "_ohrmList.js",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "286",
        "ok": "286",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "286",
        "ok": "286",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "286",
        "ok": "286",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "286",
        "ok": "286",
        "ko": "-"
    },
    "percentiles2": {
        "total": "286",
        "ok": "286",
        "ko": "-"
    },
    "percentiles3": {
        "total": "286",
        "ok": "286",
        "ko": "-"
    },
    "percentiles4": {
        "total": "286",
        "ok": "286",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-91-43ae7": {
        type: "REQUEST",
        name: "request_91",
path: "request_91",
pathFormatted: "req_request-91-43ae7",
stats: {
    "name": "request_91",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "440",
        "ok": "440",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "440",
        "ok": "440",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "440",
        "ok": "440",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "440",
        "ok": "440",
        "ko": "-"
    },
    "percentiles2": {
        "total": "440",
        "ok": "440",
        "ko": "-"
    },
    "percentiles3": {
        "total": "440",
        "ok": "440",
        "ko": "-"
    },
    "percentiles4": {
        "total": "440",
        "ok": "440",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-93-dbbcb": {
        type: "REQUEST",
        name: "request_93",
path: "request_93",
pathFormatted: "req_request-93-dbbcb",
stats: {
    "name": "request_93",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "percentiles2": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "percentiles3": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "percentiles4": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-94-27500": {
        type: "REQUEST",
        name: "request_94",
path: "request_94",
pathFormatted: "req_request-94-27500",
stats: {
    "name": "request_94",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "400",
        "ok": "400",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "400",
        "ok": "400",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "400",
        "ok": "400",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "400",
        "ok": "400",
        "ko": "-"
    },
    "percentiles2": {
        "total": "400",
        "ok": "400",
        "ko": "-"
    },
    "percentiles3": {
        "total": "400",
        "ok": "400",
        "ko": "-"
    },
    "percentiles4": {
        "total": "400",
        "ok": "400",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-95-02d41": {
        type: "REQUEST",
        name: "request_95",
path: "request_95",
pathFormatted: "req_request-95-02d41",
stats: {
    "name": "request_95",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "229",
        "ok": "229",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "229",
        "ok": "229",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "229",
        "ok": "229",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "229",
        "ok": "229",
        "ko": "-"
    },
    "percentiles2": {
        "total": "229",
        "ok": "229",
        "ko": "-"
    },
    "percentiles3": {
        "total": "229",
        "ok": "229",
        "ko": "-"
    },
    "percentiles4": {
        "total": "229",
        "ok": "229",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_a04-clickingont-00bab": {
        type: "REQUEST",
        name: "A04_ClickingOnTimeModule",
path: "A04_ClickingOnTimeModule",
pathFormatted: "req_a04-clickingont-00bab",
stats: {
    "name": "A04_ClickingOnTimeModule",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1407",
        "ok": "1407",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1407",
        "ok": "1407",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1407",
        "ok": "1407",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1407",
        "ok": "1407",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1407",
        "ok": "1407",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1407",
        "ok": "1407",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1407",
        "ok": "1407",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_a04-clickingont-b2234": {
        type: "REQUEST",
        name: "A04_ClickingOnTimeModule Redirect 1",
path: "A04_ClickingOnTimeModule Redirect 1",
pathFormatted: "req_a04-clickingont-b2234",
stats: {
    "name": "A04_ClickingOnTimeModule Redirect 1",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "376",
        "ok": "376",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "376",
        "ok": "376",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "376",
        "ok": "376",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "376",
        "ok": "376",
        "ko": "-"
    },
    "percentiles2": {
        "total": "376",
        "ok": "376",
        "ko": "-"
    },
    "percentiles3": {
        "total": "376",
        "ok": "376",
        "ko": "-"
    },
    "percentiles4": {
        "total": "376",
        "ok": "376",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_viewemployeetim-ad422": {
        type: "REQUEST",
        name: "viewEmployeeTimesheet.js",
path: "viewEmployeeTimesheet.js",
pathFormatted: "req_viewemployeetim-ad422",
stats: {
    "name": "viewEmployeeTimesheet.js",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "226",
        "ok": "226",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "226",
        "ok": "226",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "226",
        "ok": "226",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "226",
        "ok": "226",
        "ko": "-"
    },
    "percentiles2": {
        "total": "226",
        "ok": "226",
        "ko": "-"
    },
    "percentiles3": {
        "total": "226",
        "ok": "226",
        "ko": "-"
    },
    "percentiles4": {
        "total": "226",
        "ok": "226",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-124-6f41c": {
        type: "REQUEST",
        name: "request_124",
path: "request_124",
pathFormatted: "req_request-124-6f41c",
stats: {
    "name": "request_124",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "217",
        "ok": "217",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "217",
        "ok": "217",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "217",
        "ok": "217",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "217",
        "ok": "217",
        "ko": "-"
    },
    "percentiles2": {
        "total": "217",
        "ok": "217",
        "ko": "-"
    },
    "percentiles3": {
        "total": "217",
        "ok": "217",
        "ko": "-"
    },
    "percentiles4": {
        "total": "217",
        "ok": "217",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-125-b3349": {
        type: "REQUEST",
        name: "request_125",
path: "request_125",
pathFormatted: "req_request-125-b3349",
stats: {
    "name": "request_125",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "341",
        "ok": "341",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "341",
        "ok": "341",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "341",
        "ok": "341",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "341",
        "ok": "341",
        "ko": "-"
    },
    "percentiles2": {
        "total": "341",
        "ok": "341",
        "ko": "-"
    },
    "percentiles3": {
        "total": "341",
        "ok": "341",
        "ko": "-"
    },
    "percentiles4": {
        "total": "341",
        "ok": "341",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-126-4efb6": {
        type: "REQUEST",
        name: "request_126",
path: "request_126",
pathFormatted: "req_request-126-4efb6",
stats: {
    "name": "request_126",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "354",
        "ok": "354",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "354",
        "ok": "354",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "354",
        "ok": "354",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "354",
        "ok": "354",
        "ko": "-"
    },
    "percentiles2": {
        "total": "354",
        "ok": "354",
        "ko": "-"
    },
    "percentiles3": {
        "total": "354",
        "ok": "354",
        "ko": "-"
    },
    "percentiles4": {
        "total": "354",
        "ok": "354",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-127-79647": {
        type: "REQUEST",
        name: "request_127",
path: "request_127",
pathFormatted: "req_request-127-79647",
stats: {
    "name": "request_127",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "356",
        "ok": "356",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "356",
        "ok": "356",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "356",
        "ok": "356",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "356",
        "ok": "356",
        "ko": "-"
    },
    "percentiles2": {
        "total": "356",
        "ok": "356",
        "ko": "-"
    },
    "percentiles3": {
        "total": "356",
        "ok": "356",
        "ko": "-"
    },
    "percentiles4": {
        "total": "356",
        "ok": "356",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-128-9fb64": {
        type: "REQUEST",
        name: "request_128",
path: "request_128",
pathFormatted: "req_request-128-9fb64",
stats: {
    "name": "request_128",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "percentiles2": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "percentiles3": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "percentiles4": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-129-eceb8": {
        type: "REQUEST",
        name: "request_129",
path: "request_129",
pathFormatted: "req_request-129-eceb8",
stats: {
    "name": "request_129",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "241",
        "ok": "241",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "241",
        "ok": "241",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "241",
        "ok": "241",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "241",
        "ok": "241",
        "ko": "-"
    },
    "percentiles2": {
        "total": "241",
        "ok": "241",
        "ko": "-"
    },
    "percentiles3": {
        "total": "241",
        "ok": "241",
        "ko": "-"
    },
    "percentiles4": {
        "total": "241",
        "ok": "241",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_a05-clickingonl-a8799": {
        type: "REQUEST",
        name: "A05_ClickingOnLogout",
path: "A05_ClickingOnLogout",
pathFormatted: "req_a05-clickingonl-a8799",
stats: {
    "name": "A05_ClickingOnLogout",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1471",
        "ok": "1471",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1471",
        "ok": "1471",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1471",
        "ok": "1471",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1471",
        "ok": "1471",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1471",
        "ok": "1471",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1471",
        "ok": "1471",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1471",
        "ok": "1471",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_a05-clickingonl-79dad": {
        type: "REQUEST",
        name: "A05_ClickingOnLogout Redirect 1",
path: "A05_ClickingOnLogout Redirect 1",
pathFormatted: "req_a05-clickingonl-79dad",
stats: {
    "name": "A05_ClickingOnLogout Redirect 1",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "percentiles2": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "percentiles3": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "percentiles4": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-131-22210": {
        type: "REQUEST",
        name: "request_131",
path: "request_131",
pathFormatted: "req_request-131-22210",
stats: {
    "name": "request_131",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1768",
        "ok": "1768",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1768",
        "ok": "1768",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1768",
        "ok": "1768",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1768",
        "ok": "1768",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1768",
        "ok": "1768",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1768",
        "ok": "1768",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1768",
        "ok": "1768",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-132-2c1cc": {
        type: "REQUEST",
        name: "request_132",
path: "request_132",
pathFormatted: "req_request-132-2c1cc",
stats: {
    "name": "request_132",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "245",
        "ok": "245",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "245",
        "ok": "245",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "245",
        "ok": "245",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "245",
        "ok": "245",
        "ko": "-"
    },
    "percentiles2": {
        "total": "245",
        "ok": "245",
        "ko": "-"
    },
    "percentiles3": {
        "total": "245",
        "ok": "245",
        "ko": "-"
    },
    "percentiles4": {
        "total": "245",
        "ok": "245",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
